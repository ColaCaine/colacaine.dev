''global peace force''

not a real classified government unit,
just a placeholder/template piece to showcase why the keycode
system can be used for.